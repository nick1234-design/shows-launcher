package com.nick.showslauncher

import android.content.Context
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

// Saves the last rows to a file so the launcher can draw instantly on startup
// while fresh rows load in the background.
object Cache {

    private const val FILE = "rows_cache.json"

    fun save(context: Context, rows: List<Pair<Row, List<Show>>>) {
        runCatching {
            val array = JSONArray()
            for ((row, shows) in rows) {
                val showArray = JSONArray()
                for (s in shows) {
                    showArray.put(
                        JSONObject().apply {
                            put("id", s.id)
                            put("title", s.title)
                            put("poster", s.poster ?: "")
                            put("background", s.background ?: "")
                            put("description", s.description)
                            put("season", s.season ?: -1)
                            put("episode", s.episode ?: -1)
                        }
                    )
                }
                array.put(
                    JSONObject().apply {
                        put("catalogId", row.catalogId)
                        put("shows", showArray)
                    }
                )
            }
            File(context.filesDir, FILE).writeText(array.toString())
        }
    }

    fun load(context: Context): List<Pair<Row, List<Show>>> {
        return runCatching {
            val file = File(context.filesDir, FILE)
            if (!file.exists()) return emptyList()
            val array = JSONArray(file.readText())
            val byId = Config.ROWS.associateBy { it.catalogId }
            val saved = HashMap<String, List<Show>>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val showArray = obj.getJSONArray("shows")
                val shows = ArrayList<Show>()
                for (j in 0 until showArray.length()) {
                    val s = showArray.getJSONObject(j)
                    shows.add(
                        Show(
                            id = s.getString("id"),
                            title = s.optString("title"),
                            poster = s.optString("poster").ifEmpty { null },
                            background = s.optString("background").ifEmpty { null },
                            description = s.optString("description"),
                            season = s.optInt("season", -1).takeIf { it >= 0 },
                            episode = s.optInt("episode", -1).takeIf { it >= 0 }
                        )
                    )
                }
                saved[obj.getString("catalogId")] = shows
            }
            // Keep the order and titles from Config, and drop rows that were removed.
            Config.ROWS.mapNotNull { row ->
                val shows = saved[row.catalogId]
                if (byId.containsKey(row.catalogId) && !shows.isNullOrEmpty()) row to shows else null
            }
        }.getOrDefault(emptyList())
    }
}
