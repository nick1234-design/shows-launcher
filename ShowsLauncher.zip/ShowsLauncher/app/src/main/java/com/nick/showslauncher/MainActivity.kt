package com.nick.showslauncher

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.format.DateFormat
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row as LayoutRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import coil.compose.AsyncImage
import java.util.Date
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay

data class AppShortcut(val label: String, val intent: Intent, val icon: ImageBitmap)

class MainActivity : ComponentActivity() {

    // Bumped every time the launcher comes back to the screen, which reloads the rows.
    private var refreshKey by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // A launcher should never close itself when Back is pressed.
        onBackPressedDispatcher.addCallback(this) { }

        val shortcuts = loadShortcuts(this)

        setContent {
            LauncherScreen(
                refreshKey = refreshKey,
                shortcuts = shortcuts,
                onOpen = ::openShow,
                onLaunch = ::launchApp
            )
        }
    }

    override fun onResume() {
        super.onResume()
        refreshKey++
    }

    private fun openShow(show: Show) {
        // Shows with a next episode (the What's Next row) open that episode.
        val path = if (show.season != null && show.episode != null) {
            "${show.id}/${show.id}:${show.season}:${show.episode}"
        } else {
            show.id
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("stremio:///detail/series/$path")))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Stremio not found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchApp(shortcut: AppShortcut) {
        try {
            startActivity(shortcut.intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open ${shortcut.label}", Toast.LENGTH_SHORT).show()
        }
    }
}

fun loadShortcuts(context: Context): List<AppShortcut> {
    val pm = context.packageManager
    return Config.PINNED_PACKAGES.mapNotNull { pkg ->
        runCatching {
            val intent = pm.getLeanbackLaunchIntentForPackage(pkg)
                ?: pm.getLaunchIntentForPackage(pkg)
                ?: return@runCatching null
            val icon = pm.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
            AppShortcut(pkg, intent, icon)
        }.getOrNull()
    }
}

@Composable
fun LauncherScreen(
    refreshKey: Int,
    shortcuts: List<AppShortcut>,
    onOpen: (Show) -> Unit,
    onLaunch: (AppShortcut) -> Unit
) {
    val context = LocalContext.current

    // Start with the saved rows so the screen is not empty while the network loads.
    var rows by remember { mutableStateOf(Cache.load(context)) }
    var loaded by remember { mutableStateOf(false) }
    var focusedShow by remember { mutableStateOf<Show?>(null) }
    var initialFocusDone by remember { mutableStateOf(false) }
    val firstCardFocus = remember { FocusRequester() }

    LaunchedEffect(refreshKey) {
        val previous = rows.toMap()
        val result = coroutineScope {
            Config.ROWS.map { row ->
                async {
                    // null means the request failed, so keep what was on screen.
                    row to runCatching { Catalog.load(row.catalogId) }.getOrNull()
                }
            }.awaitAll()
        }
        val merged = result.mapNotNull { (row, shows) ->
            val list = shows ?: previous[row]
            if (list.isNullOrEmpty()) null else row to list
        }
        rows = merged
        loaded = true
        Cache.save(context, merged)
    }

    // Put the cursor on the first poster once the rows have appeared.
    LaunchedEffect(rows.isNotEmpty()) {
        if (rows.isNotEmpty() && !initialFocusDone) {
            delay(400)
            runCatching { firstCardFocus.requestFocus() }
            initialFocusDone = true
        }
    }

    val bannerShow = focusedShow ?: rows.firstOrNull()?.second?.firstOrNull()
    val firstRowId = rows.firstOrNull()?.first?.catalogId

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0E0E12))
    ) {
        TopBar(shortcuts, onLaunch)
        Banner(bannerShow)

        if (rows.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize()) {
                Text(
                    text = if (loaded) "No shows to display. Check ADDON_URL in Config.kt." else "Loading…",
                    color = Color.White,
                    fontSize = 20.sp,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(rows, key = { it.first.catalogId }) { (row, shows) ->
                    Text(
                        text = row.title,
                        color = Color.White,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(start = 48.dp, top = 8.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 48.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        itemsIndexed(shows, key = { _, show -> show.id }) { index, show ->
                            ShowCard(
                                show = show,
                                focusRequester = if (row.catalogId == firstRowId && index == 0) firstCardFocus else null,
                                onFocus = { focusedShow = it },
                                onOpen = onOpen
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TopBar(shortcuts: List<AppShortcut>, onLaunch: (AppShortcut) -> Unit) {
    LayoutRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 48.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (shortcut in shortcuts) {
            ShortcutIcon(shortcut, onLaunch)
            Spacer(modifier = Modifier.width(10.dp))
        }
        Spacer(modifier = Modifier.weight(1f))
        Clock()
    }
}

@Composable
fun ShortcutIcon(shortcut: AppShortcut, onLaunch: (AppShortcut) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(shape)
            .border(if (focused) 2.dp else 0.dp, Color.White, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable { onLaunch(shortcut) }
    ) {
        Image(
            bitmap = shortcut.icon,
            contentDescription = shortcut.label,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun Clock() {
    val context = LocalContext.current
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(15_000)
        }
    }
    Text(
        text = DateFormat.getTimeFormat(context).format(Date(now)),
        color = Color(0xFFD3D1C7),
        fontSize = 16.sp
    )
}

@Composable
fun Banner(show: Show?) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 48.dp)
            .height(140.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF1A1A22))
    ) {
        if (show != null) {
            AsyncImage(
                model = show.background ?: show.poster,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Darken the left side so the text is easy to read.
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xF00E0E12), Color(0xA00E0E12), Color.Transparent)
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .fillMaxWidth(0.6f)
                    .padding(16.dp)
            ) {
                Text(
                    text = show.title,
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (show.season != null && show.episode != null) {
                    Text(
                        text = "Next: S${show.season} E${show.episode}",
                        color = Color(0xFF9FE1CB),
                        fontSize = 13.sp
                    )
                }
                Text(
                    text = show.description,
                    color = Color(0xFFD3D1C7),
                    fontSize = 12.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun ShowCard(
    show: Show,
    focusRequester: FocusRequester?,
    onFocus: (Show) -> Unit,
    onOpen: (Show) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.1f else 1f,
        animationSpec = tween(durationMillis = 90),
        label = "cardScale"
    )
    val shape = RoundedCornerShape(10.dp)

    Box(
        modifier = Modifier
            .width(Config.CARD_WIDTH_DP.dp)
            .height(Config.CARD_HEIGHT_DP.dp)
            .scale(scale)
            .clip(shape)
            .border(if (focused) 3.dp else 0.dp, Color.White, shape)
            .background(Color(0xFF24242C))
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocus(show)
            }
            .clickable { onOpen(show) }
    ) {
        AsyncImage(
            model = show.poster,
            contentDescription = show.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        if (show.season != null && show.episode != null) {
            Text(
                text = "S${show.season} E${show.episode}",
                color = Color.White,
                fontSize = 11.sp,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(4.dp)
                    .background(Color(0xCC0E0E12), RoundedCornerShape(4.dp))
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            )
        }
    }
}
