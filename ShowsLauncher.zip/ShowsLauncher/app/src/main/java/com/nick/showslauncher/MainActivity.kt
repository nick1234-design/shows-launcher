package com.nick.showslauncher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

class MainActivity : ComponentActivity() {

    // Bumped every time the launcher comes back to the screen, which reloads the rows.
    private var refreshKey by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // A launcher should never close itself when Back is pressed.
        onBackPressedDispatcher.addCallback(this) { }

        setContent {
            LauncherScreen(refreshKey = refreshKey, onOpen = ::openShow)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshKey++
    }

    private fun openShow(show: Show) {
        val uri = Uri.parse("stremio:///detail/series/${show.id}")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Stremio not found", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun LauncherScreen(refreshKey: Int, onOpen: (Show) -> Unit) {
    var rows by remember { mutableStateOf<List<Pair<Row, List<Show>>>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }

    LaunchedEffect(refreshKey) {
        val result = coroutineScope {
            Config.ROWS.map { row ->
                async {
                    row to runCatching { Catalog.load(row.catalogId) }
                        .getOrDefault(emptyList())
                }
            }.awaitAll()
        }
        rows = result.filter { it.second.isNotEmpty() }
        loaded = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0E0E12))
    ) {
        if (rows.isEmpty()) {
            Text(
                text = if (loaded) "No shows to display. Check ADDON_URL in Config.kt." else "Loading…",
                color = Color.White,
                fontSize = 20.sp,
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(vertical = 32.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(rows, key = { it.first.catalogId }) { (row, shows) ->
                    Text(
                        text = row.title,
                        color = Color.White,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(start = 48.dp, top = 8.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 48.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(shows, key = { it.id }) { show ->
                            ShowCard(show, onOpen)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ShowCard(show: Show, onOpen: (Show) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.1f else 1f,
        animationSpec = tween(durationMillis = 90),
        label = "cardScale"
    )
    val shape = RoundedCornerShape(10.dp)

    Box(
        modifier = Modifier
            .width(Config.CARD_WIDTH_DP.dp)
            .height(Config.CARD_HEIGHT_DP.dp)
            .scale(scale)
            .clip(shape)
            .border(if (focused) 3.dp else 0.dp, Color.White, shape)
            .background(Color(0xFF24242C))
            .onFocusChanged { focused = it.isFocused }
            .clickable { onOpen(show) }
    ) {
        AsyncImage(
            model = show.poster,
            contentDescription = show.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}
