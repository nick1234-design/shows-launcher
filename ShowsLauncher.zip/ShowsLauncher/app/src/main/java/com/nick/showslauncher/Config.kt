package com.nick.showslauncher

data class Row(val title: String, val catalogId: String)

data class Show(val id: String, val name: String, val poster: String?)

object Config {

    // Poster size in dp. Make these smaller to fit more shows on screen.
    const val CARD_WIDTH_DP = 100
    const val CARD_HEIGHT_DP = 150

    // Your addon's base URL INCLUDING the saved config segment from the
    // Configure page, with no trailing slash. For example:
    // "https://my-shows.vercel.app/12345,67890~myshows,whatsnext~myorder~hideended,imdb"
    // Tip: open your addon's manifest URL in a browser, then remove "/manifest.json".
    const val ADDON_URL = "https://YOUR-ADDON.vercel.app/YOUR_CONFIG"

    // Rows shown on the home screen, top to bottom. Empty rows are skipped.
    // Catalog ids: myshows, myshows2, whatsnext, airingtoday,
    // airingthisweek, recentlyaired, returningsoon
    val ROWS = listOf(
        Row("My Shows", "myshows"),
        Row("More Shows", "myshows2"),
        Row("What's Next", "whatsnext"),
        Row("Returning Soon", "returningsoon")
    )
}
