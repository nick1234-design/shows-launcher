package com.nick.showslauncher

import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

object Catalog {

    suspend fun load(catalogId: String): List<Show> = withContext(Dispatchers.IO) {
        val url = URL("${Config.ADDON_URL}/catalog/series/$catalogId.json")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 20_000
        try {
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val metas = JSONObject(text).optJSONArray("metas")
                ?: return@withContext emptyList<Show>()
            val shows = ArrayList<Show>()
            for (i in 0 until metas.length()) {
                val meta = metas.getJSONObject(i)
                val poster = meta.optString("poster")
                shows.add(
                    Show(
                        id = meta.getString("id"),
                        name = meta.optString("name"),
                        poster = poster.ifEmpty { null }
                    )
                )
            }
            shows
        } finally {
            conn.disconnect()
        }
    }
}
