package com.nick.showslauncher

import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

object Catalog {

    // The What's Next row names shows like "MobLand — S2 E7".
    private val episodeName = Regex("^(.*) — S(\\d+) E(\\d+)$")

    suspend fun load(catalogId: String): List<Show> = withContext(Dispatchers.IO) {
        val url = URL("${Config.ADDON_URL}/catalog/series/$catalogId.json")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 20_000
        try {
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val metas = JSONObject(text).optJSONArray("metas")
                ?: return@withContext emptyList<Show>()
            val shows = ArrayList<Show>()
            for (i in 0 until metas.length()) {
                val meta = metas.getJSONObject(i)
                val rawName = meta.optString("name")
                val match = episodeName.find(rawName)

                // Ask TMDB for smaller images so everything loads and draws faster.
                val poster = meta.optString("poster")
                    .replace("/t/p/w500/", "/t/p/w185/")
                val background = meta.optString("background")
                    .replace("/t/p/original/", "/t/p/w780/")

                shows.add(
                    Show(
                        id = meta.getString("id"),
                        title = match?.groupValues?.get(1) ?: rawName,
                        poster = poster.ifEmpty { null },
                        background = background.ifEmpty { null },
                        description = meta.optString("description")
                            .replace("⏭️", "")
                            .replace("⏭", "")
                            .trim(),
                        season = match?.groupValues?.get(2)?.toIntOrNull(),
                        episode = match?.groupValues?.get(3)?.toIntOrNull()
                    )
                )
            }
            shows
        } finally {
            conn.disconnect()
        }
    }
}
