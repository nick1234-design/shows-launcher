# Shows Launcher (Onn 4K Plus / Google TV)

Build it with the GitHub workflow (Actions > Build APK > Run workflow).
The addon address is read from addon_url.txt at build time.

Edit app/src/main/java/com/nick/showslauncher/Config.kt to change:
- ROWS: which catalogs show and what they are called
- CARD_WIDTH_DP / CARD_HEIGHT_DP: poster size
- PINNED_PACKAGES: app icons in the top bar

fixed.keystore is a permanent signing key so new builds install over old ones.
