# Shows Launcher (Onn 4K Plus / Google TV)

1. Open this folder in Android Studio and let Gradle sync.
2. Edit `ADDON_URL` in `app/src/main/java/com/nick/showslauncher/Config.kt`.
3. Build > Build APK(s). The APK is at app/build/outputs/apk/debug/app-debug.apk
4. On the Onn: enable Developer options > USB/Network debugging, then:
     adb connect <onn-ip>:5555
     adb install -r app-debug.apk
     adb shell am start -n com.nick.showslauncher/.MainActivity
5. To open it with the Home button you need the ADB workaround from the chat.
